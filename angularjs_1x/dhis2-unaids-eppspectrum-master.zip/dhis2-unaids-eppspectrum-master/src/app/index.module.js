(function() {
    'use strict';
    angular.module('threebund', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ui.router', 'ui.bootstrap',
        'mwl.confirm', 'angularSpinner', 'xml'
    ]);
})();
