(function() {
    'use strict';
    angular.module('threebund').controller('HomeController', [function() {}]);
})();
