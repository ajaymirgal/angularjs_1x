angular.module('threebund')
.value('AUTH', 'YWRtaW46ZGlzdHJpY3Q=');
